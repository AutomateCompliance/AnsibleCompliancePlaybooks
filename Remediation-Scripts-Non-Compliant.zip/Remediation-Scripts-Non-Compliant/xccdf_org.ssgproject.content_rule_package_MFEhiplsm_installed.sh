[[packages]]
name = "MFEhiplsm"
version = "*"